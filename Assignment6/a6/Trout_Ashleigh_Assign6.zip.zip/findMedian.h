#ifndef FINDMEDIAN_H_
#define FINDMEDIAN_H_
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
using namespace std; 

//define the find Median method 
int findMedian(int *arr, int size); 

#endif 
