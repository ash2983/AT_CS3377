#ifndef FINDMODE_H
#define FINDMODE_H
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
using namespace std;

//findMode function definition
int findMode(int *arr, int size);

#endif
