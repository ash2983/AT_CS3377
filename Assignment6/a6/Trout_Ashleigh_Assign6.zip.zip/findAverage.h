#ifndef FINDAVERAGE_H_
#define FINDAVERAGE_H_
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
using namespace std; 

//define the only method findAverage
int findAverage(int* arr, int size);

#endif 
